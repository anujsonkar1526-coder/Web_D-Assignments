
const mongoose = require("mongoose");

const mobileSchema = new mongoose.Schema({
    brand: String,
    model: String,
    ram: Number,
    storage: Number,
    price: Number
});

module.exports = mongoose.model("Mobile", mobileSchema);