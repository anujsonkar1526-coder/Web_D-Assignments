const express= require("express");
const mongoose= require("mongoose");
const Mobile = require("./models/Mobile")
const methodOverride = require("method-override");



const app = express();


app.use(express.urlencoded({extended:true}));
app.use(methodOverride("_method"));
app.set("view engine", "ejs");

app.use(express.static("public"));

app.get("/mobiles/new", (req,res)=>{
    res.render("new");
});

app.get("/", (req, res) => {
    res.redirect("/mobiles");
});

app.post("/mobiles", async(req,res)=>{
    let mobile = new Mobile(req.body);
    await mobile.save();

    res.redirect("/mobiles");
});


app.get("/mobiles", async(req,res)=>{

    let mobiles = await Mobile.find();

    res.render("index",{mobiles});
});


app.get("/mobiles/search", async(req,res)=>{

    let mobiles = await Mobile.find({
        brand:req.query.brand
    });

    res.render("index",{mobiles});
});

app.get("/mobiles/:id/edit", async(req,res)=>{

    let mobile = await Mobile.findById(req.params.id);

    res.render("edit",{mobile});
});

app.put("/mobiles/:id", async(req,res)=>{

    await Mobile.findByIdAndUpdate(
        req.params.id,
        req.body
    );

    res.redirect("/mobiles");
});



app.delete("/mobiles/:id", async(req,res)=>{

    await Mobile.findByIdAndDelete(req.params.id);

    res.redirect("/mobiles");
});


mongoose.connect("mongodb://127.0.0.1:27017/mobileStore")
.then(() => {
    console.log("MongoDB Connected");
})
.catch((err) => {
    console.log(err);
});

app.listen(3000, ()=>{
    console.log("Server is running on port 3000");
});
