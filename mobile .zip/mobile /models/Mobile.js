
const mongoose = require("mongoose");

const mobileSchema = new mongoose.Schema({
    brand: String,
    model: String,
    ram: String,
    storage: String,
    price: Number
});

module.exports = mongoose.model("Mobile", mobileSchema);